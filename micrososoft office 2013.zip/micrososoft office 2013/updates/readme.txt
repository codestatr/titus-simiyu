Any patches placed in this folder will be applied during initial install.
